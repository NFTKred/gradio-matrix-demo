"""Pure request building: turn an Operation plus arguments into a PreparedRequest."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from typing import Any
from urllib.parse import quote

from matrix_kred._types import NOT_GIVEN, Operation
from matrix_kred._version import API_MAJOR_VERSION, __version__
from matrix_kred.errors import MissingTokenError


@dataclass
class PreparedRequest:
    method: str
    url: str
    params: list[tuple[str, str]]
    json: dict[str, Any] | None
    headers: dict[str, str]


def _query_scalar(v: Any) -> str:
    if isinstance(v, Enum):
        v = v.value
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def _jsonable(v: Any) -> Any:
    if isinstance(v, Enum):
        return _jsonable(v.value)
    if hasattr(v, "model_dump"):
        return v.model_dump(mode="json", by_alias=True, exclude_unset=True)
    if isinstance(v, Mapping):
        return {k: _jsonable(x) for k, x in v.items() if x is not NOT_GIVEN}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v if x is not NOT_GIVEN]
    return v


def build_request(
    op: Operation,
    args: Mapping[str, Any],
    *,
    token: str | None,
    idempotency_key: str | None,
) -> PreparedRequest:
    by_py = {p.py_name: p for p in op.params}
    for key in args:
        if key not in by_py:
            raise TypeError(f"{op.op_id}() got an unexpected argument {key!r}")

    if op.auth and not token:
        raise MissingTokenError("No API token: pass token= or set MATRIX_API_TOKEN")

    url = op.path
    params: list[tuple[str, str]] = []
    body: dict[str, Any] = {}
    for p in op.params:
        value = args.get(p.py_name, NOT_GIVEN)
        if p.location == "path":
            if value is NOT_GIVEN or value is None:
                raise TypeError(f"{op.op_id}() missing required path argument {p.py_name!r}")
            url = url.replace("{" + p.name + "}", quote(_query_scalar(value) if isinstance(value, Enum) else str(value), safe=""))
        elif value is NOT_GIVEN:
            continue
        elif p.location == "query":
            if value is None:
                continue
            items = value if isinstance(value, (list, tuple)) else [value]
            params.extend((p.name, _query_scalar(x)) for x in items if x is not None and x is not NOT_GIVEN)
        else:
            body[p.name] = _jsonable(value)

    headers = {
        "API-Version": str(API_MAJOR_VERSION),
        "User-Agent": f"matrix-kred-python/{__version__}",
    }
    if op.auth:
        headers["Authorization"] = f"Bearer {token}"
    if op.idempotency_key and idempotency_key:
        headers["Idempotency-Key"] = idempotency_key

    return PreparedRequest(
        method=op.method,
        url=url,
        params=params,
        json=body if op.has_body else None,
        headers=headers,
    )
