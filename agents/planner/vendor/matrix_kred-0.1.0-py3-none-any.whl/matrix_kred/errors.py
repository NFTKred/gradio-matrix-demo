"""Typed error hierarchy for matrix-kred."""

from __future__ import annotations

from typing import Any

import httpx

__all__ = [
    "APIConnectionError",
    "APIResponseValidationError",
    "APIStatusError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "IdempotentReplayError",
    "MatrixError",
    "MissingTokenError",
    "NotAvailableError",
    "NotFoundError",
    "OutcomeUnknownError",
    "PaymentRequiredError",
    "PermissionDeniedError",
    "RateLimitError",
    "ServerError",
    "UnsupportedAPIVersionError",
    "ValidationError",
    "WebhookVerificationError",
    "error_from_response",
]


class MatrixError(Exception):
    """Base class for all matrix-kred errors."""


class MissingTokenError(MatrixError):
    """No API token was provided and MATRIX_API_TOKEN is not set."""


class APIConnectionError(MatrixError):
    """The request could not reach the API."""

    def __init__(self, message: str, *, request: httpx.Request | None = None) -> None:
        super().__init__(message)
        self.request = request


class APITimeoutError(APIConnectionError):
    """The request timed out."""


class OutcomeUnknownError(MatrixError):
    """A write may or may not have been applied; the original error is __cause__."""

    def __init__(self, message: str, *, operation: str, idempotency_key: str | None = None) -> None:
        super().__init__(message)
        self.operation = operation
        self.idempotency_key = idempotency_key


class APIResponseValidationError(MatrixError):
    """The server accepted the request (2xx) but the SDK could not parse the response.

    The original parsing error is __cause__. The request was not retried.
    """

    def __init__(
        self,
        message: str,
        *,
        response: httpx.Response,
        operation: str,
        idempotency_key: str | None = None,
        status: int,
    ) -> None:
        super().__init__(message)
        self.response = response
        self.operation = operation
        self.idempotency_key = idempotency_key
        self.status = status


class WebhookVerificationError(MatrixError):
    """Webhook signature verification failed."""


class APIStatusError(MatrixError):
    """The API returned a non-success status."""

    def __init__(
        self,
        *,
        status: int,
        type: str,
        code: str,
        message: str,
        details: list[dict[str, Any]] | None = None,
        response: httpx.Response | None = None,
        idempotency_key: str | None = None,
    ) -> None:
        super().__init__(f"{status} {code}: {message}")
        self.status = status
        self.type = type
        self.code = code
        self.message = message
        self.details = details
        self.response = response
        self.idempotency_key = idempotency_key


class BadRequestError(APIStatusError):
    """HTTP 400."""


class UnsupportedAPIVersionError(BadRequestError):
    """Code unsupported_api_version."""


class AuthenticationError(APIStatusError):
    """HTTP 401."""


class PaymentRequiredError(APIStatusError):
    """HTTP 402."""


class PermissionDeniedError(APIStatusError):
    """HTTP 403."""


class NotFoundError(APIStatusError):
    """HTTP 404."""


class ConflictError(APIStatusError):
    """HTTP 409."""


class IdempotentReplayError(ConflictError):
    """Code idempotent_replay."""


class ValidationError(APIStatusError):
    """HTTP 422."""


class RateLimitError(APIStatusError):
    """HTTP 429."""

    def __init__(self, *, retry_after: float | None = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.retry_after = retry_after


class NotAvailableError(APIStatusError):
    """HTTP 501."""


class ServerError(APIStatusError):
    """Other 5xx."""


_BY_STATUS: dict[int, type[APIStatusError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    402: PaymentRequiredError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
    501: NotAvailableError,
}

_VERSION_SUFFIX = " — this SDK targets API v2; upgrade matrix-kred."


def _parse_retry_after(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        return float(value.strip())
    except ValueError:
        return None


def error_from_response(
    response: httpx.Response, *, idempotency_key: str | None = None
) -> APIStatusError:
    """Build the typed APIStatusError for a non-success response."""
    status = response.status_code
    err_type = "unknown"
    code = f"http_{status}"
    message = ""
    details: list[dict[str, Any]] | None = None

    body: Any = None
    try:
        body = response.json()
    except ValueError:
        pass
    err = body.get("error") if isinstance(body, dict) else None
    if isinstance(err, dict):
        err_type = str(err.get("type", err_type))
        code = str(err.get("code", code))
        message = str(err.get("message", ""))
        raw_details = err.get("details")
        details = raw_details if isinstance(raw_details, list) else None
    else:
        message = response.text[:200]

    cls: type[APIStatusError]
    if code == "unsupported_api_version":
        cls = UnsupportedAPIVersionError
        message += _VERSION_SUFFIX
    elif code == "idempotent_replay":
        cls = IdempotentReplayError
    elif status in _BY_STATUS:
        cls = _BY_STATUS[status]
    elif 500 <= status < 600:
        cls = ServerError
    else:
        cls = APIStatusError

    kwargs: dict[str, Any] = {
        "status": status,
        "type": err_type,
        "code": code,
        "message": message,
        "details": details,
        "response": response,
        "idempotency_key": idempotency_key,
    }
    if cls is RateLimitError:
        kwargs["retry_after"] = _parse_retry_after(response.headers.get("Retry-After"))
    return cls(**kwargs)
