"""Client transport (source of truth).

The sync client in ``_sync/`` is generated from this module by
``scripts/gen_sync.py``. Keep it mechanically convertible: use ``asyncio``
only for ``asyncio.sleep`` and no other async-only APIs.
"""

from __future__ import annotations

import asyncio
import os
import uuid
from collections.abc import Mapping
from functools import cached_property
from types import TracebackType
from typing import TYPE_CHECKING, Any

import httpx
import pydantic

from matrix_kred import models
from matrix_kred._async.pagination import AsyncPage
from matrix_kred._async.resources import (
    AgentsResource,
    AgentWebhooksResource,
    AllowancesResource,
    BillingResource,
    FilesResource,
    GiftsResource,
    LedgerResource,
    MessagesResource,
    NodesResource,
    PlatformResource,
    RepliesResource,
    ReportsResource,
    ThreadsResource,
)
from matrix_kred._operations import OPERATIONS
from matrix_kred._request import build_request
from matrix_kred._retry import Outcome, decide
from matrix_kred._types import Operation
from matrix_kred.errors import (
    APIConnectionError,
    APIResponseValidationError,
    APIStatusError,
    APITimeoutError,
    OutcomeUnknownError,
    RateLimitError,
    error_from_response,
)

if TYPE_CHECKING:
    from typing_extensions import Self

DEFAULT_BASE_URL = "https://api.matrix.kred"


class AsyncMatrixClient:
    def __init__(
        self,
        token: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 2,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self.token = token if token is not None else os.environ.get("MATRIX_API_TOKEN")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._owns_http = http_client is None
        self._http = http_client if http_client is not None else httpx.AsyncClient(timeout=timeout)

    def with_token(self, token: str) -> AsyncMatrixClient:
        """Return a client acting as another identity, sharing this client's connection pool.

        The derived client never closes the shared HTTP client.
        """
        derived = AsyncMatrixClient(
            token,
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
            http_client=self._http,
        )
        derived._sleep = self._sleep  # type: ignore[method-assign]
        return derived

    # Resources: each is a cached property returning ``<Resource>(self)``.
    @cached_property
    def nodes(self) -> NodesResource:
        return NodesResource(self)

    @cached_property
    def threads(self) -> ThreadsResource:
        return ThreadsResource(self)

    @cached_property
    def replies(self) -> RepliesResource:
        return RepliesResource(self)

    @cached_property
    def messages(self) -> MessagesResource:
        return MessagesResource(self)

    @cached_property
    def reports(self) -> ReportsResource:
        return ReportsResource(self)

    @cached_property
    def files(self) -> FilesResource:
        return FilesResource(self)

    @cached_property
    def billing(self) -> BillingResource:
        return BillingResource(self)

    @cached_property
    def gifts(self) -> GiftsResource:
        return GiftsResource(self)

    @cached_property
    def agents(self) -> AgentsResource:
        return AgentsResource(self)

    @cached_property
    def agent_webhooks(self) -> AgentWebhooksResource:
        return AgentWebhooksResource(self)

    @cached_property
    def ledger(self) -> LedgerResource:
        return LedgerResource(self)

    @cached_property
    def allowances(self) -> AllowancesResource:
        return AllowancesResource(self)

    @cached_property
    def platform(self) -> PlatformResource:
        return PlatformResource(self)

    async def _sleep(self, seconds: float) -> None:
        await asyncio.sleep(seconds)

    async def _call(
        self, op_id: str, args: Mapping[str, Any], idempotency_key: str | None
    ) -> Any:
        op = OPERATIONS[op_id]
        key: str | None = None
        if op.idempotency_key:
            key = idempotency_key or str(uuid.uuid4())
        prepared = build_request(op, args, token=self.token, idempotency_key=key)
        url = self.base_url + prepared.url

        attempt = 0
        while True:
            cause: Exception
            try:
                resp = await self._http.request(
                    prepared.method,
                    url,
                    params=tuple(prepared.params),
                    json=prepared.json,
                    headers=prepared.headers,
                    timeout=self.timeout,
                )
            except httpx.RequestError as exc:
                # Any RequestError other than a connect failure (including
                # DecodingError and TooManyRedirects) may have reached the server.
                is_connect = isinstance(exc, (httpx.ConnectError, httpx.ConnectTimeout))
                outcome = Outcome(transport="connect" if is_connect else "other")
                cause = exc
            else:
                if resp.is_success:
                    return self._decode_or_raise(op, resp, key, args)
                status_error = error_from_response(resp, idempotency_key=key)
                retry_after = (
                    status_error.retry_after if isinstance(status_error, RateLimitError) else None
                )
                outcome = Outcome(
                    status=resp.status_code, code=status_error.code, retry_after=retry_after
                )
                cause = status_error

            decision = decide(op, outcome, attempt, self.max_retries)
            if decision.action == "retry":
                await self._sleep(decision.delay)
                attempt += 1
                continue
            if decision.action == "outcome_unknown":
                raise OutcomeUnknownError(
                    f"{op.op_id}: the outcome is unknown; the request may have been applied "
                    f"({cause!r}). Check whether the action completed before retrying with a "
                    f"new idempotency key.",
                    operation=op.op_id,
                    idempotency_key=key,
                ) from cause
            if isinstance(cause, APIStatusError):
                raise cause
            if isinstance(cause, httpx.TimeoutException):
                raise APITimeoutError(
                    f"{op.op_id}: request timed out", request=_request_of(cause)
                ) from cause
            raise APIConnectionError(
                f"{op.op_id}: connection error: {cause}", request=_request_of(cause)
            ) from cause

    def _decode_or_raise(
        self, op: Operation, resp: httpx.Response, key: str | None, args: Mapping[str, Any]
    ) -> Any:
        """Decode a 2xx response; a parse failure is never retried (the request succeeded)."""
        try:
            return self._decode(op, resp, args)
        except (ValueError, pydantic.ValidationError, KeyError, TypeError, AttributeError) as exc:
            message = (
                f"{op.op_id}: the server accepted the request (HTTP {resp.status_code}) "
                f"but the SDK could not parse the response: {exc}"
            )
            if op.charged:
                message += (
                    " The action was very likely performed; do not retry with a new "
                    "idempotency key without checking first."
                )
            raise APIResponseValidationError(
                message,
                response=resp,
                operation=op.op_id,
                idempotency_key=key,
                status=resp.status_code,
            ) from exc

    def _decode(self, op: Operation, resp: httpx.Response, args: Mapping[str, Any]) -> Any:
        if op.response == "json":
            return getattr(models, str(op.response_model)).model_validate(resp.json())
        if op.response == "page":
            return self._decode_page(op, resp, args)
        if op.response == "csv":
            return resp.text
        if op.response == "binary":
            return resp.content
        return resp.json()

    def _decode_page(
        self, op: Operation, resp: httpx.Response, args: Mapping[str, Any]
    ) -> AsyncPage[Any]:
        raw = getattr(models, str(op.response_model)).model_validate(resp.json())
        return AsyncPage(raw, client=self, op_id=op.op_id, args=args)

    async def aclose(self) -> None:
        """Close the HTTP client if this client created it."""
        if self._owns_http:
            await self._http.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()


def _request_of(exc: httpx.RequestError) -> httpx.Request | None:
    try:
        return exc.request
    except RuntimeError:
        return None
