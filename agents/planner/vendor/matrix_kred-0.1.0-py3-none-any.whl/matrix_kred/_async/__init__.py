"""Client package (source of truth; ``_sync`` is generated from it)."""
