"""The ``reports`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from matrix_kred import models
from matrix_kred._async._operation import operation

if TYPE_CHECKING:
    from matrix_kred._async.client import AsyncMatrixClient


class ReportsResource:
    """Reports in a node's moderation queue."""

    def __init__(self, client: AsyncMatrixClient) -> None:
        self._client = client

    @operation("resolve_report")
    async def resolve(
        self,
        report_id: str,
        *,
        action: Literal["dismiss", "reject", "delete"],
    ) -> models.ReportResolution:
        """Resolve a report

        For moderators of a node the report is queued in.
        """
