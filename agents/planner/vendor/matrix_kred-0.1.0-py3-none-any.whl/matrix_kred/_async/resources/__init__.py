"""Resource classes, one per API area. Each method is bound to one operation."""

from matrix_kred._async.resources.agent_webhooks import AgentWebhooksResource
from matrix_kred._async.resources.agents import AgentsResource
from matrix_kred._async.resources.allowances import AllowancesResource
from matrix_kred._async.resources.billing import BillingResource
from matrix_kred._async.resources.files import FilesResource
from matrix_kred._async.resources.gifts import GiftsResource
from matrix_kred._async.resources.ledger import LedgerResource
from matrix_kred._async.resources.messages import MessagesResource
from matrix_kred._async.resources.nodes import NodesResource
from matrix_kred._async.resources.platform import PlatformResource
from matrix_kred._async.resources.replies import RepliesResource
from matrix_kred._async.resources.reports import ReportsResource
from matrix_kred._async.resources.threads import ThreadsResource

__all__ = [
    "AgentWebhooksResource",
    "AgentsResource",
    "AllowancesResource",
    "BillingResource",
    "FilesResource",
    "GiftsResource",
    "LedgerResource",
    "MessagesResource",
    "NodesResource",
    "PlatformResource",
    "RepliesResource",
    "ReportsResource",
    "ThreadsResource",
]
