"""The ``gifts`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from matrix_kred import models
from matrix_kred._async._operation import operation
from matrix_kred._async.pagination import AsyncPage
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._async.client import AsyncMatrixClient


class GiftsResource:
    """Gifts: give gifts and read gift counters."""

    def __init__(self, client: AsyncMatrixClient) -> None:
        self._client = client

    @operation("list_gifts")
    async def list(
        self,
        *,
        channel: str | NotGiven = NOT_GIVEN,
        status: Literal["all", "active", "cancelled", "expired"] | NotGiven = NOT_GIVEN,
        tag: str | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> AsyncPage[models.GiftResource]:
        """List gifts

        Returns one window of gifts per category; `has_more` is always false.
        """

    @operation("give_gift")
    async def give(
        self,
        *,
        address: str | None | NotGiven = NOT_GIVEN,
        collection: str | None | NotGiven = NOT_GIVEN,
        collection_id: str | None | NotGiven = NOT_GIVEN,
        drop: str | None | NotGiven = NOT_GIVEN,
        gift_amount_decimal: str | None | NotGiven = NOT_GIVEN,
        gift_currency: str | None | NotGiven = NOT_GIVEN,
        merchant_id: str | None | NotGiven = NOT_GIVEN,
        message: str | None | NotGiven = NOT_GIVEN,
        nft: str | None | NotGiven = NOT_GIVEN,
        order_id: str | None | NotGiven = NOT_GIVEN,
        payment_amount_decimal: str | None | NotGiven = NOT_GIVEN,
        payment_currency: str | None | NotGiven = NOT_GIVEN,
        payment_id: str | None | NotGiven = NOT_GIVEN,
        payment_method: str | None | NotGiven = NOT_GIVEN,
        purchase_auth: str | None | NotGiven = NOT_GIVEN,
        quantity: int | NotGiven = NOT_GIVEN,
        sale: str | None | NotGiven = NOT_GIVEN,
        text: str | None | NotGiven = NOT_GIVEN,
        to: str | None | NotGiven = NOT_GIVEN,
        wallet: str | None | NotGiven = NOT_GIVEN,
        wallet_key: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.GiftPurchaseResource:
        """Give a gift

        You pay. An idempotency key makes a retry return the original result instead of
        buying again.
        """

    @operation("get_gift_counters")
    async def counters(
        self,
        *,
        channel: str | NotGiven = NOT_GIVEN,
        tag: str | NotGiven = NOT_GIVEN,
        user: str | None | NotGiven = NOT_GIVEN,
    ) -> models.GiftLevelsResource:
        """Get gift activity counters"""

    @operation("get_gift_counters_batch")
    async def counters_batch(
        self,
        *,
        users: str,
        channel: str | NotGiven = NOT_GIVEN,
        tag: str | NotGiven = NOT_GIVEN,
    ) -> models.GiftLevelsList:
        """Get several users' gift counters"""

    @operation("get_gift_invoice")
    async def get_invoice(self, invoice_id: str) -> models.InvoiceResource:
        """Get a purchase invoice"""
