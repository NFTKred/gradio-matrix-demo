"""The ``messages`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from matrix_kred import models
from matrix_kred._async._operation import operation
from matrix_kred._async.pagination import AsyncPage
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._async.client import AsyncMatrixClient


class MessagesResource:
    """Messages: any thread or reply."""

    def __init__(self, client: AsyncMatrixClient) -> None:
        self._client = client

    @operation("list_message_replies")
    async def list_replies(
        self,
        message_id: str,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
        since: int | None | NotGiven = NOT_GIVEN,
        updated_since: int | None | NotGiven = NOT_GIVEN,
    ) -> AsyncPage[models.ReplyResource]:
        """List replies to a message"""

    @operation("create_message_reply")
    async def reply(
        self,
        message_id: str,
        *,
        media: list[str] | None | NotGiven = NOT_GIVEN,
        text: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.ReplyResource:
        """Reply to a message

        Free, on the same terms as `threads.reply`. An idempotency key makes a retry
        return the original reply instead of posting another.
        """

    @operation("list_message_gifts")
    async def list_gifts(
        self,
        message_id: str,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> AsyncPage[models.MessageGiftResource]:
        """List gifts on a message"""

    @operation("update_message")
    async def update(
        self,
        message_id: str,
        *,
        media: list[str] | None | NotGiven = NOT_GIVEN,
        metadata: dict[str, Any] | None | NotGiven = NOT_GIVEN,
        text: str | None | NotGiven = NOT_GIVEN,
        title: str | None | NotGiven = NOT_GIVEN,
    ) -> Any:
        """Edit message

        Only the message's author may edit it.
        """

    @operation("delete_message")
    async def delete(self, message_id: str) -> Any:
        """Delete message

        Allowed for the message's author, or a node's owner or holders of its `moderate`
        role.
        """

    @operation("report_message")
    async def report(
        self,
        message_id: str,
        *,
        reason: Literal[
            "spam",
            "abuse",
            "copyright",
            "violence",
            "explicit",
            "threats",
            "privacy",
            "suicide",
            "other",
        ]
        | NotGiven = NOT_GIVEN,
        text: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.ReportResource:
        """Report a message

        An idempotency key makes a retry return the original response.
        """

    @operation("moderate_message")
    async def moderate(
        self,
        message_id: str,
        *,
        approve: bool | None | NotGiven = NOT_GIVEN,
        boring: Literal["confirmed", "possible", "none"] | None | NotGiven = NOT_GIVEN,
        bot: Literal["confirmed", "possible", "none"] | None | NotGiven = NOT_GIVEN,
        controversy: float | None | NotGiven = NOT_GIVEN,
        image: models.ImageAnalysis | None | NotGiven = NOT_GIVEN,
        interest: float | None | NotGiven = NOT_GIVEN,
        profanity: Literal["confirmed", "possible", "none"]
        | None
        | NotGiven = NOT_GIVEN,
        score: float | None | NotGiven = NOT_GIVEN,
        sentiment: float | None | NotGiven = NOT_GIVEN,
        spam: Literal["confirmed", "possible", "none"] | None | NotGiven = NOT_GIVEN,
        subjectivity: float | None | NotGiven = NOT_GIVEN,
    ) -> Any:
        """Moderate message

        Only the node's moderators may call this: its owner and anyone with the
        `moderate` role.
        """
