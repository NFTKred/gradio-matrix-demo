"""The ``replies`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matrix_kred import models
from matrix_kred._async._operation import operation

if TYPE_CHECKING:
    from matrix_kred._async.client import AsyncMatrixClient


class RepliesResource:
    """Replies."""

    def __init__(self, client: AsyncMatrixClient) -> None:
        self._client = client

    @operation("get_reply")
    async def get(self, reply_id: str) -> models.ReplyResource:
        """Get reply"""
