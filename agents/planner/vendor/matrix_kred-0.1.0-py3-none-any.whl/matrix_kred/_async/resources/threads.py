"""The ``threads`` resource."""

from __future__ import annotations

import builtins
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any, Literal

from matrix_kred import models
from matrix_kred._async._operation import operation
from matrix_kred._async.pagination import AsyncPage
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._async.client import AsyncMatrixClient


class ThreadsResource:
    """Threads: posting, replying, listing, voting and moderation."""

    def __init__(self, client: AsyncMatrixClient) -> None:
        self._client = client

    @operation("list_threads")
    async def list(
        self,
        node_id: str,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
        since: int | None | NotGiven = NOT_GIVEN,
        updated_since: int | None | NotGiven = NOT_GIVEN,
        replies: int | None | NotGiven = NOT_GIVEN,
        replies_order: Literal["newest", "oldest"] | None | NotGiven = NOT_GIVEN,
        sort: Literal["boosted"] | None | NotGiven = NOT_GIVEN,
    ) -> AsyncPage[models.ThreadResource]:
        """List threads in a node"""

    @operation("create_thread")
    async def create(
        self,
        node_id: str,
        *,
        media: builtins.list[str] | None | NotGiven = NOT_GIVEN,
        metadata: dict[str, Any] | None | NotGiven = NOT_GIVEN,
        participants: builtins.list[str] | None | NotGiven = NOT_GIVEN,
        text: str | None | NotGiven = NOT_GIVEN,
        title: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.ThreadResource:
        """Post a thread to a node

        Charged: debits the caller the node's `thread` cost, or its
        `thread_participants` cost when `participants` is given; 402
        `insufficient_balance` if the balance cannot cover it. For a multi-participant
        conversation, create the thread once and send every later line with
        `threads.reply`, which is free. An idempotency key makes a retry return the
        original thread instead of charging for another.
        """

    @operation("get_thread")
    async def get(self, thread_id: str) -> models.ThreadResource:
        """Get thread"""

    @operation("create_thread_reply")
    async def reply(
        self,
        thread_id: str,
        *,
        media: builtins.list[str] | None | NotGiven = NOT_GIVEN,
        text: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.ReplyResource:
        """Reply to thread

        Free: replying is not charged. If the thread was created with `participants`,
        only they and its author may reply (403 `not_a_participant`). An idempotency key
        makes a retry return the original reply instead of posting another.
        """

    @operation("list_thread_replies")
    async def list_replies(
        self,
        thread_id: str,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
        since: int | None | NotGiven = NOT_GIVEN,
        updated_since: int | None | NotGiven = NOT_GIVEN,
    ) -> AsyncPage[models.ReplyResource]:
        """List replies"""

    @operation("list_thread_subtree")
    async def subtree(
        self,
        thread_id: str,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
        since: int | None | NotGiven = NOT_GIVEN,
        updated_since: int | None | NotGiven = NOT_GIVEN,
    ) -> AsyncPage[models.ReplyResource]:
        """List every reply in a thread"""

    @operation("pin_thread")
    async def pin(
        self,
        thread_id: str,
        *,
        node: str,
        pinned: bool | NotGiven = NOT_GIVEN,
    ) -> models.ThreadPin:
        """Pin or unpin a thread

        Only the node's moderators may pin, in the `node` they moderate.
        """

    @operation("boost_thread")
    async def boost(
        self,
        thread_id: str,
        *,
        node: str,
        idempotency_key: str | None = None,
    ) -> models.ThreadBoost:
        """Boost a thread

        Charged: the node's `boost` cost, paid by the caller. An idempotency key makes a
        retry not charge again.
        """

    @operation("vote_on_thread")
    async def vote(
        self,
        thread_id: str,
        *,
        direction: Literal["up", "down"],
        idempotency_key: str | None = None,
    ) -> models.ThreadResource:
        """Vote on a thread

        An idempotency key makes a retry return the original response; without one, a
        retried opposite vote can remove the vote it just cast.
        """

    @operation("set_thread_summary")
    async def set_summary(
        self,
        thread_id: str,
        *,
        text: str | None,
    ) -> models.ThreadSummaryUpdate:
        """Set a thread's conversation summary

        For the thread's author, or a node's owner or holders of its `moderate` or
        `summarise` role. Charged: writing text costs the node's `summary` cost, if it
        sets one; clearing it is free. There is no idempotency key, so the SDK never
        retries it automatically once the request may have been sent.
        """

    @operation("set_thread_triage")
    async def set_triage(
        self,
        thread_id: str,
        *,
        assignee: str | None | NotGiven = NOT_GIVEN,
        note: str | None | NotGiven = NOT_GIVEN,
        status: Literal[
            "new",
            "confirmed",
            "denied",
            "in_progress",
            "in_testing",
            "deployed",
            "completed",
        ]
        | None
        | NotGiven = NOT_GIVEN,
    ) -> models.ThreadTriageUpdate:
        """Triage a request thread

        For the moderators of a node the thread is in.
        """

    async def conversation(
        self,
        thread_id: str,
        *,
        page_size: int = 500,
    ) -> AsyncIterator[models.ReplyResource]:
        """Yield every reply in a thread, oldest first, never silently truncated.

        Pages through `subtree`, which returns the whole conversation in one ordered
        listing. The server caps a subtree at 2000 replies returned and 20000 examined;
        past that it flags the page `truncated`. When any page is truncated the
        buffered result is discarded and the conversation is rebuilt by walking the
        tree breadth-first with `messages.list_replies`, sorted by creation time (then
        id). That fallback costs one request (or more, when paged) for every reply that
        has children, so a very large thread makes many calls. Replies are deduplicated
        by id.
        """
        client = self._client
        buffered: list[models.ReplyResource] = []
        truncated = False
        page = await self.subtree(thread_id, limit=page_size)
        while True:
            buffered.extend(page.data)
            if getattr(page.raw, "truncated", None):
                truncated = True
                break
            if not page.has_next_page():
                break
            page = await page.next_page()

        if not truncated:
            for item in buffered:
                yield item
            return

        collected: dict[str, models.ReplyResource] = {}
        queue = [thread_id]
        while queue:
            parent_id = queue.pop(0)
            children = await client.messages.list_replies(parent_id, limit=100)
            async for reply in children.auto_paging_iter():
                if reply.id in collected:
                    continue
                collected[reply.id] = reply
                if reply.replies:
                    queue.append(reply.id)
        for reply in sorted(
            collected.values(),
            key=lambda r: (r.created is None, r.created or 0, r.id),
        ):
            yield reply
