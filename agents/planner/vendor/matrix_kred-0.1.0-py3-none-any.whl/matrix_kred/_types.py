"""Shared types for the operation table."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


class NotGiven:
    """Sentinel for an argument the caller did not supply (use NOT_GIVEN)."""

    def __bool__(self) -> bool:
        return False

    def __repr__(self) -> str:
        return "NOT_GIVEN"


NOT_GIVEN = NotGiven()


@dataclass(frozen=True)
class Param:
    name: str
    py_name: str
    location: Literal["path", "query", "body"]
    required: bool


@dataclass(frozen=True)
class Operation:
    op_id: str
    method: str
    path: str
    summary: str
    auth: bool
    idempotency_key: bool
    charged: bool
    response: Literal["json", "page", "csv", "binary", "any"]
    response_model: str | None
    item_model: str | None
    params: tuple[Param, ...]
    has_body: bool
