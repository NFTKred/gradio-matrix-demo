"""Verify and parse signed webhook deliveries from Matrix.

Call :func:`construct_event` (or :func:`verify_signature`) from your HTTP
handler with the *raw* request body, before acting on anything in it.

Matrix can deliver the same notice more than once. Deduplicating on the
event's ``delivery`` ID (also sent in ``X-Matrix-Delivery``) is the caller's
job; this module only checks authenticity and freshness.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import time
from collections.abc import Mapping

from pydantic import ValidationError

from . import models
from .errors import WebhookVerificationError

__all__ = ["TOLERANCE_SECONDS", "construct_event", "verify_signature"]

TOLERANCE_SECONDS = 300
SIGNATURE_HEADER = "X-Matrix-Signature"

_DIGITS = re.compile(r"[0-9]{1,15}")
_HEX = re.compile(r"[0-9a-fA-F]+")


def _get_header(headers: Mapping[str, str], name: str) -> str | None:
    wanted = name.lower()
    for key, value in headers.items():
        if isinstance(key, str) and key.lower() == wanted:
            return value
    return None


def _parse_signature_header(value: str) -> tuple[str, list[str]]:
    timestamp: str | None = None
    candidates: list[str] = []
    for part in value.split(","):
        key, sep, val = part.strip().partition("=")
        if not sep:
            raise WebhookVerificationError("malformed X-Matrix-Signature header")
        if key == "t":
            if timestamp is not None or not _DIGITS.fullmatch(val):
                raise WebhookVerificationError("malformed X-Matrix-Signature header")
            timestamp = val
        elif key == "v1":
            if not _HEX.fullmatch(val):
                raise WebhookVerificationError("malformed X-Matrix-Signature header")
            candidates.append(val)
        # Unknown keys (future schemes) are ignored.
    if timestamp is None or not candidates:
        raise WebhookVerificationError("malformed X-Matrix-Signature header")
    return timestamp, candidates


def verify_signature(
    payload: bytes,
    headers: Mapping[str, str],
    secret: str,
    *,
    tolerance: int = TOLERANCE_SECONDS,
    now: float | None = None,
) -> None:
    """Check a webhook delivery's signature and age; raise if it is not valid.

    ``payload`` must be the raw request body bytes exactly as received (not a
    re-serialised parsed body). ``headers`` is any mapping of request headers;
    ``X-Matrix-Signature`` is looked up case-insensitively. ``secret`` is the
    webhook secret as given (its UTF-8 bytes; not base64-decoded).

    Raises :class:`~matrix_kred.errors.WebhookVerificationError` if the header
    is missing or malformed, the timestamp is more than ``tolerance`` seconds
    from ``now`` (default: the current time), or no ``v1`` signature matches.
    Comparison is constant-time.

    Deduplicating on ``delivery`` is the caller's job.
    """
    if not isinstance(payload, bytes | bytearray):
        raise TypeError(
            "payload must be the raw request body as bytes; pass the bytes exactly as "
            "received (re-encoding a parsed body breaks the signature)"
        )
    header = _get_header(headers, SIGNATURE_HEADER)
    if header is None:
        raise WebhookVerificationError("missing X-Matrix-Signature header")
    if not isinstance(header, str):
        raise WebhookVerificationError("malformed X-Matrix-Signature header")
    timestamp, candidates = _parse_signature_header(header)

    current = time.time() if now is None else now
    # Written so that NaN fails closed.
    try:
        in_window = abs(current - int(timestamp)) <= tolerance
    except (OverflowError, ValueError, TypeError) as exc:
        raise WebhookVerificationError("signature timestamp outside tolerance") from exc
    if not in_window:
        raise WebhookVerificationError("signature timestamp outside tolerance")

    expected = hmac.new(
        secret.encode("utf-8"),
        f"{timestamp}.".encode() + bytes(payload),
        hashlib.sha256,
    ).hexdigest()
    matched = False
    for candidate in candidates:
        # Evaluate every candidate; do not short-circuit.
        if hmac.compare_digest(expected.encode("ascii"), candidate.encode("ascii")):
            matched = True
    if not matched:
        raise WebhookVerificationError("signature mismatch")


def construct_event(
    payload: bytes,
    headers: Mapping[str, str],
    secret: str,
    *,
    tolerance: int = TOLERANCE_SECONDS,
    now: float | None = None,
) -> models.MessageCreatedEvent | models.WebhookPingEvent:
    """Verify a delivery (see :func:`verify_signature`) and parse it into an event model.

    Parsing happens only after the signature has been verified. Invalid JSON,
    an unknown ``event`` or a body that fails model validation raises
    :class:`~matrix_kred.errors.WebhookVerificationError`.

    Deduplicating on ``delivery`` is the caller's job.
    """
    verify_signature(payload, headers, secret, tolerance=tolerance, now=now)
    try:
        body = json.loads(payload)
    except ValueError as exc:  # includes UnicodeDecodeError
        raise WebhookVerificationError("webhook body is not valid JSON") from exc
    if not isinstance(body, dict):
        raise WebhookVerificationError("webhook body is not a JSON object")
    event = body.get("event")
    try:
        if event == "message.created":
            return models.MessageCreatedEvent.model_validate(body)
        if event == "ping":
            return models.WebhookPingEvent.model_validate(body)
    except ValidationError as exc:
        raise WebhookVerificationError(f"invalid {event} event body") from exc
    raise WebhookVerificationError(f"unknown event {event!r}")
