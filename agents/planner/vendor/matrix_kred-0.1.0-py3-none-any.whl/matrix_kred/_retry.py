"""Pure per-operation retry policy. No I/O; the transport calls decide()."""

from __future__ import annotations

import math
import random
from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal

from ._types import Operation

MAX_RETRY_AFTER = 60.0
_IDEMPOTENT_METHODS = frozenset({"GET", "PUT", "PATCH", "DELETE"})


@dataclass(frozen=True)
class Outcome:
    status: int | None = None
    code: str | None = None
    retry_after: float | None = None
    # "connect" means the request was never sent.
    transport: Literal["connect", "other"] | None = None


@dataclass(frozen=True)
class Decision:
    action: Literal["retry", "raise", "outcome_unknown"]
    delay: float = 0.0


def backoff(attempt: int, rand: Callable[[], float] = random.random) -> float:
    return float(min(0.5 * 2**attempt, 8.0) * (0.75 + 0.25 * rand()))


def decide(op: Operation, outcome: Outcome, attempt: int, max_retries: int) -> Decision:
    """Decide what to do after a failed attempt.

    `attempt` is the number of retries already made (0 after the first try).
    Rule order matters: charged operations must never be re-sent once the
    request may have reached the server.
    """
    can_retry = attempt < max_retries
    status = outcome.status

    # 1. Rate limited.
    if status == 429:
        retry_after = outcome.retry_after
        if retry_after is not None and (not math.isfinite(retry_after) or retry_after < 0):
            retry_after = None
        if can_retry and (retry_after is None or retry_after <= MAX_RETRY_AFTER):
            return Decision("retry", backoff(attempt) if retry_after is None else retry_after)
        return Decision("raise")

    # 2. Another request with the same idempotency key is still running.
    if status == 409 and outcome.code == "idempotency_in_progress":
        return Decision("retry", backoff(attempt)) if can_retry else Decision("raise")

    # 3. Never sent, so safe even for charged operations.
    if outcome.transport == "connect":
        return Decision("retry", backoff(attempt)) if can_retry else Decision("raise")

    # 4. The request may have been processed.
    if outcome.transport == "other" or (status is not None and status >= 500 and status != 501):
        if op.charged:
            return Decision("outcome_unknown")
        if (op.method in _IDEMPOTENT_METHODS or op.idempotency_key) and can_retry:
            return Decision("retry", backoff(attempt))
        return Decision("raise")

    # 5. Anything else.
    return Decision("raise")
