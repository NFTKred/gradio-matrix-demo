# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``@operation`` decorator for resource methods."""

from __future__ import annotations

import functools
import inspect
from collections.abc import Callable
from typing import Any, TypeVar

F = TypeVar("F", bound=Callable[..., Any])

# Wire params the SDK always sends and never exposes in the public signature.
FIXED_ARGS: dict[str, dict[str, Any]] = {"open_topup_link": {"format": "json"}}


def operation(op_id: str) -> Callable[[F], F]:
    def decorate(fn: F) -> F:
        sig = inspect.signature(fn)

        @functools.wraps(fn)
        def wrapper(self: Any, *a: Any, **kw: Any) -> Any:
            bound = sig.bind(self, *a, **kw)
            bound.apply_defaults()
            args = dict(bound.arguments)
            args.pop(next(iter(sig.parameters)), None)
            args.update(FIXED_ARGS.get(op_id, {}))
            idempotency_key = args.pop("idempotency_key", None)
            return self._client._call(op_id, args, idempotency_key)

        wrapper.__matrix_op__ = op_id  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorate
