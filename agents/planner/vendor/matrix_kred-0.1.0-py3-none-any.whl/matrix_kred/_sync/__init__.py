# GENERATED from _async by scripts/gen_sync.py — do not edit
"""Client package (source of truth; ``_sync`` is generated from it)."""
