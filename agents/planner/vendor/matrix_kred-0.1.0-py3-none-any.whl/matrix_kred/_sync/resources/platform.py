# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``platform`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from matrix_kred import models
from matrix_kred._sync._operation import operation
from matrix_kred._sync.pagination import Page
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class PlatformResource:
    """Platform: capabilities, profiles, NFTs, marketplace, keys, leaderboard and wallets."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("get_capabilities")
    def capabilities(self) -> models.CapabilitiesResource:
        """List optional features

        No token is needed. Call this first to see which optional features are on.
        """

    @operation("get_user_profile")
    def get_user(self, user_id: str) -> models.ProfileResource:
        """Get a user profile"""

    @operation("list_nfts")
    def list_nfts(
        self,
        *,
        channel: str | None | NotGiven = NOT_GIVEN,
        tag: str | None | NotGiven = NOT_GIVEN,
        wallet: str | None | NotGiven = NOT_GIVEN,
        user: str | None | NotGiven = NOT_GIVEN,
        collection: str | None | NotGiven = NOT_GIVEN,
        search: str | None | NotGiven = NOT_GIVEN,
        on_sale: bool | None | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.NftResource]:
        """List NFTs"""

    @operation("list_marketplace")
    def list_marketplace(
        self,
        *,
        channel: str,
        tag: str | None | NotGiven = NOT_GIVEN,
        currency: str | None | NotGiven = NOT_GIVEN,
        price_low: str | None | NotGiven = NOT_GIVEN,
        price_high: str | None | NotGiven = NOT_GIVEN,
        search: str | None | NotGiven = NOT_GIVEN,
        status: str | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.ListingResource]:
        """List marketplace listings"""

    @operation("create_my_key")
    def create_key(
        self,
        *,
        name: str | None | NotGiven = NOT_GIVEN,
        revoke_existing: bool | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.CreatedKeyResource:
        """Create an API key

        The token is shown once, in the response: store it before doing anything else.
        """

    @operation("list_my_keys")
    def list_keys(
        self,
        *,
        status: Literal["active", "revoked"] | None | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | None | NotGiven = NOT_GIVEN,
    ) -> Page[models.MyKeyResource]:
        """List your API keys"""

    @operation("revoke_my_key")
    def revoke_key(self, key_id: str) -> models.MyKeyResource:
        """Revoke one of your API keys"""

    @operation("get_leaderboard")
    def leaderboard(
        self,
        *,
        channel: str,
        window: str | NotGiven = NOT_GIVEN,
        week: str | None | NotGiven = NOT_GIVEN,
        sort: Literal["score", "balance"] | NotGiven = NOT_GIVEN,
        days: int | None | NotGiven = NOT_GIVEN,
        user: str | None | NotGiven = NOT_GIVEN,
        nfts: bool | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.LeaderResource]:
        """Get a channel's leaderboard"""

    @operation("list_wallets")
    def list_wallets(self) -> models.WalletList:
        """List wallets"""
