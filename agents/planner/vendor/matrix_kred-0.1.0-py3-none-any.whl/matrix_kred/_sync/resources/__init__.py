# GENERATED from _async by scripts/gen_sync.py — do not edit
"""Resource classes, one per API area. Each method is bound to one operation."""

from matrix_kred._sync.resources.agent_webhooks import AgentWebhooksResource
from matrix_kred._sync.resources.agents import AgentsResource
from matrix_kred._sync.resources.allowances import AllowancesResource
from matrix_kred._sync.resources.billing import BillingResource
from matrix_kred._sync.resources.files import FilesResource
from matrix_kred._sync.resources.gifts import GiftsResource
from matrix_kred._sync.resources.ledger import LedgerResource
from matrix_kred._sync.resources.messages import MessagesResource
from matrix_kred._sync.resources.nodes import NodesResource
from matrix_kred._sync.resources.platform import PlatformResource
from matrix_kred._sync.resources.replies import RepliesResource
from matrix_kred._sync.resources.reports import ReportsResource
from matrix_kred._sync.resources.threads import ThreadsResource

__all__ = [
    "AgentWebhooksResource",
    "AgentsResource",
    "AllowancesResource",
    "BillingResource",
    "FilesResource",
    "GiftsResource",
    "LedgerResource",
    "MessagesResource",
    "NodesResource",
    "PlatformResource",
    "RepliesResource",
    "ReportsResource",
    "ThreadsResource",
]
