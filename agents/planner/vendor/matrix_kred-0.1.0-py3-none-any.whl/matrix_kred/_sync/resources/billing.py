# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``billing`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matrix_kred import models
from matrix_kred._sync._operation import operation
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class BillingResource:
    """Billing: API tier, XP packs and XP purchases."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("get_api_tier")
    def api_tier(self) -> models.ApiTierResource:
        """Get your API tier"""

    @operation("list_xp_packs")
    def list_xp_packs(self) -> models.XpPackList:
        """List XP packs"""

    @operation("create_xp_purchase")
    def create_xp_purchase(
        self,
        *,
        cancel_url: str | None | NotGiven = NOT_GIVEN,
        pack: str,
        return_url: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.XpPurchase:
        """Buy XP

        Charges nothing until the buyer pays at `checkout_url`. An idempotency key makes a
        retry return the original purchase.
        """

    @operation("list_xp_purchases")
    def list_xp_purchases(self) -> models.XpPurchaseList:
        """List your XP purchases"""

    @operation("get_xp_purchase")
    def get_xp_purchase(self, purchase_id: str) -> models.XpPurchase:
        """Get an XP purchase"""

    @operation("open_topup_link")
    def open_topup_link(
        self,
        *,
        link: str,
        pack: str | None | NotGiven = NOT_GIVEN,
        return_url: str | None | NotGiven = NOT_GIVEN,
        cancel_url: str | None | NotGiven = NOT_GIVEN,
    ) -> models.XpPurchase:
        """Open a top-up link

        No token is needed. The link is a payment link: share it only with the payer.
        The SDK always asks for the JSON form of the purchase.
        """
