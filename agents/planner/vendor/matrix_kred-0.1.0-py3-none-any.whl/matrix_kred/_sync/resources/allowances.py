# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``allowances`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matrix_kred import models
from matrix_kred._sync._operation import operation
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class AllowancesResource:
    """Allowances: let a child user spend your funds, up to a cap."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("list_allowances")
    def list(self) -> models.AllowanceList:
        """List allowances"""

    @operation("add_allowance")
    def add(
        self,
        *,
        amount_decimal: str,
        child: str,
        currency: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.AllowanceResource:
        """Set an allowance

        Adds to any existing allowance. An idempotency key is always sent, so a retry is
        safe.
        """

    @operation("get_allowance")
    def get(
        self, child_id: str, *, currency: str | None | NotGiven = NOT_GIVEN
    ) -> models.AllowanceResource:
        """Get an allowance"""

    @operation("set_allowance")
    def set(
        self,
        child_id: str,
        *,
        amount_decimal: str,
        currency: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.AllowanceResource:
        """Set an allowance to an exact amount

        Replaces the allowance. Funds are not reserved.
        """

    @operation("revoke_allowance")
    def revoke(
        self,
        child_id: str,
        *,
        currency: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.RevokedAllowanceResource:
        """Revoke an allowance

        An idempotency key makes a retry return the original result instead of a 404.
        """
