# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``replies`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matrix_kred import models
from matrix_kred._sync._operation import operation

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class RepliesResource:
    """Replies."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("get_reply")
    def get(self, reply_id: str) -> models.ReplyResource:
        """Get reply"""
