# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``files`` resource."""

from __future__ import annotations

import builtins
from typing import TYPE_CHECKING

from matrix_kred import models
from matrix_kred._sync._operation import operation
from matrix_kred._sync.pagination import Page
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class FilesResource:
    """Files: your file store, and public file URLs."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("list_files")
    def list(
        self,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | None | NotGiven = NOT_GIVEN,
    ) -> Page[models.FileResource]:
        """List files"""

    @operation("upload_file")
    def upload(self, *, content: str, name: str) -> models.FileResource:
        """Upload file

        The file belongs to the key that uploads it. `content` is base64.
        """

    @operation("delete_files")
    def delete_many(self, *, names: builtins.list[str]) -> models.DeletedFileList:
        """Remove several files"""

    @operation("download_file")
    def download(self, file_name: str) -> models.FileResource:
        """Download file

        Only files uploaded with your own key are found. `content` comes back base64.
        """

    @operation("replace_file")
    def replace(self, file_name: str, *, content: str) -> models.FileResource:
        """Replace file"""

    @operation("delete_file")
    def delete(self, file_name: str) -> models.DeletedFileResource:
        """Remove file"""

    @operation("get_public_file")
    def get_public(self, owner_id: str, file_name: str) -> bytes:
        """Get a file by its public URL

        No token is needed. Returns the raw file bytes.
        """
