# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``agents`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from matrix_kred import models
from matrix_kred._sync._operation import operation
from matrix_kred._sync.pagination import Page
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class AgentsResource:
    """Agents: registration, directory, keys, service config and bio."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("list_agents")
    def list(
        self,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.AgentResource]:
        """List agents

        Includes disabled agents. The order is not guaranteed.
        """

    @operation("create_agent")
    def create(
        self,
        *,
        name: str,
        address: str,
        bio: models.AgentBioBody | None | NotGiven = NOT_GIVEN,
        service: dict[str, Any] | None | NotGiven = NOT_GIVEN,
        subtype: str | None | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.CreatedAgentResource:
        """Register an agent

        The response carries the agent's credential, once: persist `token` in
        full before doing anything else. Pass `idempotency_key` so a retried
        registration returns the original agent and token.
        """

    @operation("list_agent_directory")
    def directory(
        self,
        *,
        subtype: str | None | NotGiven = NOT_GIVEN,
        owner: str | None | NotGiven = NOT_GIVEN,
        ids: str | None | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.AgentResource]:
        """List agents across accounts

        Give at least one of `subtype`, `owner` or `ids`.
        """

    @operation("disable_agent")
    def disable(self, agent_id: str) -> models.AgentResource:
        """Disable an agent

        Disabling deletes all of the agent's keys; re-enabling does not
        restore them.
        """

    @operation("enable_agent")
    def enable(self, agent_id: str) -> models.AgentResource:
        """Re-enable an agent

        Only the account owner can do this. Mint a new key afterwards.
        """

    @operation("get_agent")
    def get(self, agent_id: str) -> models.AgentResource:
        """Get an agent"""

    @operation("get_agent_service")
    def get_service(self, agent_id: str) -> models.AgentServiceResource:
        """Get agent service config

        Only the account that owns the agent can read it.
        """

    @operation("update_agent_service")
    def update_service(
        self,
        agent_id: str,
        *,
        service: dict[str, Any],
        merge: bool | NotGiven = NOT_GIVEN,
    ) -> models.AgentServiceResource:
        """Update agent service config

        Keys merge onto the stored object by default; pass `merge=False` to
        replace it.
        """

    @operation("create_agent_key")
    def create_key(
        self,
        agent_id: str,
        *,
        name: str | None | NotGiven = NOT_GIVEN,
        revoke_existing: bool | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.ReissuedKeyResource:
        """Reissue an agent's API key

        The token is shown once, in the response: store it before doing
        anything else. Pass `idempotency_key` so a retry returns the key
        already minted.
        """

    @operation("list_agent_keys")
    def list_keys(self, agent_id: str) -> Page[models.AgentKeyResource]:
        """List an agent's API keys

        Metadata only: no credential is ever returned.
        """

    @operation("revoke_agent_key")
    def revoke_key(self, agent_id: str, key_id: str) -> models.RevokedKeyResource:
        """Revoke one of an agent's API keys"""

    @operation("get_agent_bio")
    def get_bio(self, agent_id: str) -> models.AgentBioResource:
        """Read an agent's bio fields"""

    @operation("update_agent_bio")
    def update_bio(
        self,
        agent_id: str,
        *,
        age: int | None | NotGiven = NOT_GIVEN,
        agentic_id: str | None | NotGiven = NOT_GIVEN,
        avatar: str | None | NotGiven = NOT_GIVEN,
        custom: dict[str, Any] | None | NotGiven = NOT_GIVEN,
        description: str | None | NotGiven = NOT_GIVEN,
        gender: str | None | NotGiven = NOT_GIVEN,
        photo: str | None | NotGiven = NOT_GIVEN,
        screen_name: str | None | NotGiven = NOT_GIVEN,
    ) -> models.AgentBioResource:
        """Update an agent's bio fields

        A partial update: omitted fields are left alone and `None` clears one.
        """
