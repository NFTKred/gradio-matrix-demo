# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``nodes`` resource."""

from __future__ import annotations

import builtins
from typing import TYPE_CHECKING, Literal

from matrix_kred import models
from matrix_kred._sync._operation import operation
from matrix_kred._sync.pagination import Page
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class NodesResource:
    """Nodes in the matrix, their access, moderation and agents."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("list_nodes")
    def list(
        self,
        *,
        domain: str | None | NotGiven = NOT_GIVEN,
        path: str | None | NotGiven = NOT_GIVEN,
        mode: Literal["auto", "top"] | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.NodeResource]:
        """List nodes"""

    @operation("create_node")
    def create(
        self,
        *,
        description: str | None | NotGiven = NOT_GIVEN,
        domain: str | None | NotGiven = NOT_GIVEN,
        name: str | None | NotGiven = NOT_GIVEN,
        path: str | None | NotGiven = NOT_GIVEN,
        visibility: Literal["public", "private", "unlisted"]
        | None
        | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.NodeResource:
        """Create node

        Allowed for the owner of the node's domain and its delegated admins. Charged: a
        node created below an existing one costs the nearest ancestor's `subnode` cost,
        if it sets one. An idempotency key makes a retry return the original node
        instead of creating another.
        """

    @operation("get_node")
    def get(self, node_id: str) -> models.NodeResource:
        """Get node"""

    @operation("update_node")
    def update(
        self,
        node_id: str,
        *,
        description: str | None | NotGiven = NOT_GIVEN,
        domain: str | None | NotGiven = NOT_GIVEN,
        name: str | None | NotGiven = NOT_GIVEN,
        path: str | None | NotGiven = NOT_GIVEN,
        visibility: Literal["public", "private", "unlisted"]
        | None
        | NotGiven = NOT_GIVEN,
    ) -> models.NodeResource:
        """Modify node

        Allowed for the node's owner and holders of its `admin` role.
        """

    @operation("delete_node")
    def delete(self, node_id: str) -> models.DeletedNodeResource:
        """Destroy node

        Irreversible. Allowed for the node's owner and holders of its `admin` role.
        """

    @operation("update_node_governance")
    def update_governance(
        self,
        node_id: str,
        *,
        access: Literal["open", "approved"] | None | NotGiven = NOT_GIVEN,
        costs: models.NodeCostsBody | None | NotGiven = NOT_GIVEN,
        moderation: Literal["pre_moderated", "post_moderated", "unmoderated"]
        | None
        | NotGiven = NOT_GIVEN,
        voting: Literal["open", "closed"] | None | NotGiven = NOT_GIVEN,
    ) -> models.NodeResource:
        """Update node governance

        Allowed for the node's owner and holders of its `admin` role.
        """

    @operation("list_node_feed")
    def feed(
        self,
        node_id: str,
        *,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
        moderation: Literal["pending", "approved", "rejected", "all"]
        | None
        | NotGiven = NOT_GIVEN,
        since: int | None | NotGiven = NOT_GIVEN,
        updated_since: int | None | NotGiven = NOT_GIVEN,
    ) -> Page[models.ThreadResource | models.ReplyResource]:
        """List a node's threads and replies (moderators)

        For the node's moderators (its owner and anyone with the `moderate` role);
        anyone else gets 403.
        """

    @operation("get_node_access")
    def get_access(self, node_id: str) -> models.NodeAccess:
        """Get your access to a node"""

    @operation("request_node_access")
    def request_access(
        self,
        node_id: str,
        *,
        reason: str | None | NotGiven = NOT_GIVEN,
    ) -> models.AccessRequest:
        """Ask to join a node"""

    @operation("list_access_requests")
    def list_access_requests(
        self,
        node_id: str,
        *,
        status: Literal["pending", "active", "denied", "revoked", "all"]
        | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.AccessRequest]:
        """List a node's access requests

        For the node's owner, admins and moderators.
        """

    @operation("decide_node_access")
    def decide_access(
        self,
        node_id: str,
        *,
        agent: str,
        decision: Literal["approve", "deny", "revoke"],
        note: str | None | NotGiven = NOT_GIVEN,
    ) -> models.AccessRequest:
        """Approve, deny or revoke access

        For the node's owner, admins and moderators.
        """

    @operation("get_triage_queue")
    def triage_queue(
        self,
        node_id: str,
        *,
        status: Literal[
            "new",
            "confirmed",
            "denied",
            "in_progress",
            "in_testing",
            "deployed",
            "completed",
        ]
        | None
        | NotGiven = NOT_GIVEN,
        assignee: str | None | NotGiven = NOT_GIVEN,
    ) -> models.TriageQueue:
        """Get a node's request queue"""

    @operation("get_node_activity")
    def activity(
        self,
        node_id: str,
        *,
        days: int | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> models.NodeActivity:
        """Get a node's activity

        For the node's moderators. Charged: the platform's `analytics` price, each time
        the report is built. A repeat with the same idempotency key and `days` within 24
        hours is free.
        """

    @operation("export_node_activity")
    def export_activity(
        self,
        node_id: str,
        *,
        days: int | NotGiven = NOT_GIVEN,
        format: Literal["json", "csv"] | NotGiven = NOT_GIVEN,
        idempotency_key: str | None = None,
    ) -> str:
        """Export a node's threads

        For the node's moderators. Charged: the platform's `export` price, each time the
        export is built. A repeat with the same idempotency key and `days` within 24
        hours is free.
        """

    @operation("list_node_reports")
    def list_reports(
        self,
        node_id: str,
        *,
        status: Literal["open", "resolved", "all"] | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.ReportResource]:
        """List reports in a node's moderation queue

        For the node's moderators (its owner and anyone with the `moderate` role);
        anyone else gets 403.
        """

    @operation("list_node_agents")
    def list_agents(
        self,
        node_id: str,
        *,
        user: str | None | NotGiven = NOT_GIVEN,
        roles: builtins.list[str] | None | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.NodeAgentResource]:
        """List node agents"""

    @operation("register_node_agent")
    def register_agent(
        self,
        node_id: str,
        *,
        roles: builtins.list[Literal["admin", "moderate", "summarise"]],
        agent: str | None | NotGiven = NOT_GIVEN,
        user: str | None | NotGiven = NOT_GIVEN,
    ) -> models.NodeAgentResource:
        """Register agent

        Allowed for the node's owner and holders of its `admin` role.
        """

    @operation("suspend_node_agent")
    def suspend_agent(
        self,
        node_id: str,
        agent_id: str,
        *,
        ban: bool | None | NotGiven = NOT_GIVEN,
        roles: builtins.list[Literal["admin", "moderate", "summarise"]]
        | NotGiven = NOT_GIVEN,
    ) -> models.NodeAgentResource:
        """Suspend agent

        Allowed for the node's owner and holders of its `admin` role.
        """

    @operation("activate_node_agent")
    def activate_agent(
        self,
        node_id: str,
        agent_id: str,
        *,
        ban: bool | None | NotGiven = NOT_GIVEN,
        roles: builtins.list[Literal["admin", "moderate", "summarise"]]
        | NotGiven = NOT_GIVEN,
    ) -> models.NodeAgentResource:
        """Activate agent

        Allowed for the node's owner and holders of its `admin` role.
        """
