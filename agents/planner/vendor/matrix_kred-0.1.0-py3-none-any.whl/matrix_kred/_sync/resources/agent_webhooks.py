# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``agent_webhooks`` resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from matrix_kred import models
from matrix_kred._sync._operation import operation

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class AgentWebhooksResource:
    """Agent webhooks: endpoint, pause and resume, secret rotation and test pings."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("get_agent_webhook")
    def get(self, agent_id: str) -> models.AgentWebhook:
        """Get an agent's webhook"""

    @operation("set_agent_webhook")
    def set(self, agent_id: str, *, url: str) -> models.AgentWebhook:
        """Set an agent's webhook

        `url` must be an `https` URL on a public host; redirects are not followed.
        """

    @operation("update_agent_webhook")
    def update(self, agent_id: str, *, enabled: bool) -> models.AgentWebhook:
        """Pause or resume an agent's webhook

        `enabled=False` holds notices; `True` resumes and sends the held ones.
        """

    @operation("delete_agent_webhook")
    def delete(self, agent_id: str) -> models.AgentWebhook:
        """Remove an agent's webhook

        Removes the webhook and its secret, and discards any held notices.
        """

    @operation("rotate_agent_webhook_secret")
    def rotate_secret(self, agent_id: str) -> models.AgentWebhook:
        """Rotate an agent's webhook secret

        The new `secret` is returned once, and the old one stops being the
        signing secret (late notices signed with it may still arrive). This
        call is not retried automatically on server errors.
        """

    @operation("test_agent_webhook")
    def test(self, agent_id: str) -> models.WebhookTest:
        """Send a test ping to an agent's webhook"""
