# GENERATED from _async by scripts/gen_sync.py — do not edit
"""The ``ledger`` resource."""

from __future__ import annotations

import builtins
from typing import TYPE_CHECKING

from matrix_kred import models
from matrix_kred._sync._operation import operation
from matrix_kred._sync.pagination import Page
from matrix_kred._types import NOT_GIVEN, NotGiven

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient


class LedgerResource:
    """Ledger: transaction history and balances."""

    def __init__(self, client: MatrixClient) -> None:
        self._client = client

    @operation("list_ledger_entries")
    def list(
        self,
        *,
        user: str | None | NotGiven = NOT_GIVEN,
        actions: builtins.list[str] | None | NotGiven = NOT_GIVEN,
        currency: str | NotGiven = NOT_GIVEN,
        channel: str | None | NotGiven = NOT_GIVEN,
        cursor: str | None | NotGiven = NOT_GIVEN,
        limit: int | NotGiven = NOT_GIVEN,
    ) -> Page[models.LedgerEntryResource]:
        """List ledger entries"""

    @operation("get_balance")
    def balance(
        self,
        *,
        user: str | None | NotGiven = NOT_GIVEN,
        currency: str | None | NotGiven = NOT_GIVEN,
        currencies: builtins.list[str] | None | NotGiven = NOT_GIVEN,
        wallet: str | None | NotGiven = NOT_GIVEN,
    ) -> models.BalanceResource:
        """Get balance"""

    @operation("get_balances")
    def balances(
        self, *, users: str, currency: str | None | NotGiven = NOT_GIVEN
    ) -> models.BalanceList:
        """Get several users' balances"""
