# GENERATED from _async by scripts/gen_sync.py — do not edit
"""Pagination (source of truth for ``AsyncPage`` and the generated ``Page``)."""

from __future__ import annotations

from collections import abc
from collections.abc import Iterator, Mapping
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from pydantic import BaseModel

if TYPE_CHECKING:
    from matrix_kred._sync.client import MatrixClient

T = TypeVar("T")


class Page(Generic[T]):
    data: list[T]
    has_more: bool
    next_cursor: str | None
    raw: BaseModel

    def __init__(
        self,
        raw: BaseModel,
        *,
        client: MatrixClient,
        op_id: str,
        args: Mapping[str, Any],
    ) -> None:
        self.raw = raw
        self.data = list(getattr(raw, "data", None) or [])
        self.has_more = bool(getattr(raw, "has_more", False))
        self.next_cursor = getattr(raw, "next_cursor", None)
        self._client = client
        self._op_id = op_id
        self._args = dict(args)

    def __iter__(self) -> abc.Iterator[T]:
        return iter(self.data)

    def __len__(self) -> int:
        return len(self.data)

    def has_next_page(self) -> bool:
        return self.has_more and self.next_cursor is not None

    def next_page(self) -> Page[T]:
        if not self.has_next_page():
            raise ValueError("no next page")
        args = {**self._args, "cursor": self.next_cursor}
        page: Page[T] = self._client._call(self._op_id, args, None)
        return page

    def auto_paging_iter(self) -> Iterator[T]:
        seen: set[Any] = set()
        page = self
        while True:
            for item in page.data:
                item_id = getattr(item, "id", None)
                if item_id is not None:
                    if item_id in seen:
                        continue
                    seen.add(item_id)
                yield item
            if not page.has_next_page():
                return
            page = page.next_page()
